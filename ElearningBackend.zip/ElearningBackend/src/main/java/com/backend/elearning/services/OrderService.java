package com.backend.elearning.services;

import com.backend.elearning.models.Order;

public interface OrderService {

	public String saveOrder(Order order);

}
